from django.shortcuts import render

from django.http import HttpRequest   # any program to return response
from django.shortcuts import get_object_or_404 # if object doesn't exists
from rest_framework.response import Response # status response (if everything works fine->200)
from rest_framework.views import APIView # use so that normal views returns the data
from rest_framework import status
from . models import employees
from . serializers import employeeSerializer


# Create class based-views which inherits from an API.
class employeeList(APIView):

    # get: return all employee in a model
    # post: create new employee

    def get(self,request):
        # print("______")

        employee1 = employees.objects.all()
        serializer = employeeSerializer(employee1,many=True)
        print("-----",serializer.data)
        return Response(serializer.data)


    def post(self):
        pass

